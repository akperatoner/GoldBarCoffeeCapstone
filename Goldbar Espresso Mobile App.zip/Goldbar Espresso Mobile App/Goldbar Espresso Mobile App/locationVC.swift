//
//  locationVC.swift
//  Goldbar Espresso Mobile App
//
//  Created by Jessica Miller on 11/8/21.
//
//  Map functionality created to show Gold Bar Espresso on both a standard
//  and satellite view map, animated created for zoom effect. Done by Jessica.

import Foundation
import UIKit
import MapKit
import CoreLocation

class locationVC: UIViewController, MKMapViewDelegate{
    
    @IBOutlet weak var mapView: MKMapView! //map UI
    @IBOutlet weak var mapType: UISegmentedControl! //standard/satellite view seg control
    
    override func viewDidLoad(){
        super.viewDidLoad()
        
        let addressString = "3141 S McClintock Dr, Tempe, AZ, 85281" //Gold Bar Espresso address
            CLGeocoder().geocodeAddressString(addressString, completionHandler:
                {(placemarks, error) in
                    
                    if error != nil {
                        print("Geocode failed: \(error!.localizedDescription)")
                        
                    } else if placemarks!.count > 0 {
                        let placemark = placemarks![0]
                        let span = MKCoordinateSpan.init(latitudeDelta: 0.05, longitudeDelta: 0.05)
                        let region = MKCoordinateRegion(center: placemark.location!.coordinate, span: span)
                        
                        self.mapView.setRegion(region, animated: true) //zoom in effect on map
                        
                        //Creating the red pin that drops on the map
                        let ani = MKPointAnnotation()
                        ani.coordinate = placemark.location!.coordinate
                        ani.title = "Gold Bar Espresso"
                        ani.subtitle = "Come on in!"
                        
                        self.mapView.addAnnotation(ani)
                    }
            })
    }
    
    override func didReceiveMemoryWarning(){
        super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
    }
    
    //Allowing user to switch between map modes
    @IBAction func showMap(_ sender: Any) {
        switch(mapType.selectedSegmentIndex)
        {
        case 0: //standard view
            mapView.mapType = MKMapType.standard
        
        case 1: //satellite view
           mapView.mapType = MKMapType.satellite
        
        default: //set to standard to begin with
            mapView.mapType = MKMapType.standard
        }
    }
}
    


