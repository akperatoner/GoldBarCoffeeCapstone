//
//  gameVC.swift
//  Goldbar Espresso Mobile App
//
//  Created by Jessica Miller on 11/9/21.
//

import Foundation
import UIKit

class gameVC: UIViewController{
    @IBOutlet weak var person: UIImageView!
    @IBOutlet weak var a1: UIImageView!
    @IBOutlet weak var a2: UIImageView!
    @IBOutlet weak var a3: UIImageView!
    @IBOutlet weak var a4: UIImageView!
    @IBOutlet weak var a5: UIImageView!
    @IBOutlet weak var timerVal: UILabel!
    @IBOutlet weak var result: UILabel!
    var timer : Timer?
    var counter  = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.person.image = UIImage(named: "stickFigure.png")
        self.a1.image = UIImage(named: "coffee.png")
        self.a2.image = UIImage(named: "coffee.png")
        self.a3.image = UIImage(named: "coffee.png")
        self.a4.image = UIImage(named: "coffee.png")
        self.a5.image = UIImage(named: "coffee.png")
        
        timer = Timer();
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(gameVC.count), userInfo: nil, repeats: true)
        
    }
    @objc func count()
    {
        counter = counter + 1
        let hours = Int(counter) / 3600
        let minutes = Int(counter) / 60 % 60
        let seconds = Int(counter) % 60
        timerVal.text  = String(format:"%02i:%02i:%02i", hours, minutes, seconds)
        if(seconds == 20)
        {
            if(self.a1.isHidden == true)
            {
                if(self.a2.isHidden == true)
                {
                    if(self.a3.isHidden == true)
                    {
                        if(self.a4.isHidden == true)
                        {
                            if(self.a5.isHidden == true){
                                result.text = "You Won!"
                                timer?.invalidate()
                            }
                            else{
                                result.text = "You Lost"
                                timer?.invalidate()
                            }
                        }
                        else{
                            result.text = "You Lost"
                            timer?.invalidate()
                        }
                    }
                    else{
                        result.text = "You Lost"
                        timer?.invalidate()
                    }
                }
                else{
                    result.text = "You Lost"
                    timer?.invalidate()
                }
            }
            else if(seconds > 20)
            {
                result.text = "You Lost"
                timer?.invalidate()
            }
        }
    }
    
    @IBAction func up(_ sender: Any) {
        var frame  = self.person.frame
        frame.origin.y -= 10
        self.person.frame =  frame
        
        if(viewIntersectsView(person, second_View: a1))
        {
            self.a1.isHidden = true
        }
        if(viewIntersectsView(person, second_View: a2))
        {
            self.a2.isHidden = true
        }
        if(viewIntersectsView(person, second_View: a3))
        {
            self.a3.isHidden = true
        }
        if(viewIntersectsView(person, second_View: a4))
        {
            self.a4.isHidden = true
        }
        if(viewIntersectsView(person, second_View: a5))
        {
            self.a5.isHidden = true
        }
    }
    
    @IBAction func left(_ sender: Any) {
        var frame  = self.person.frame
        frame.origin.x -= 10
        self.person.frame =  frame
        
        if(viewIntersectsView(person, second_View: a1))
        {
            self.a1.isHidden = true
        }
        if(viewIntersectsView(person, second_View: a2))
        {
            self.a2.isHidden = true
        }
        if(viewIntersectsView(person, second_View: a3))
        {
            self.a3.isHidden = true
        }
        if(viewIntersectsView(person, second_View: a4))
        {
            self.a4.isHidden = true
        }
        if(viewIntersectsView(person, second_View: a5))
        {
            self.a5.isHidden = true
        }
    }
    
    @IBAction func right(_ sender: Any) {
        var frame  = self.person.frame
        frame.origin.x += 10
        self.person.frame =  frame
        
        if(viewIntersectsView(person, second_View: a1))
        {
            self.a1.isHidden = true
        }
        if(viewIntersectsView(person, second_View: a2))
        {
            self.a2.isHidden = true
        }
        if(viewIntersectsView(person, second_View: a3))
        {
            self.a3.isHidden = true
        }
        if(viewIntersectsView(person, second_View: a4))
        {
            self.a4.isHidden = true
        }
        if(viewIntersectsView(person, second_View: a5))
        {
            self.a5.isHidden = true
        }
    }
    
    @IBAction func down(_ sender: Any) {
        var frame  = self.person.frame
        frame.origin.y += 10
        self.person.frame =  frame
        
        if(viewIntersectsView(person, second_View: a1))
        {
            self.a1.isHidden = true
        }
        if(viewIntersectsView(person, second_View: a2))
        {
            self.a2.isHidden = true
        }
        if(viewIntersectsView(person, second_View: a3))
        {
            self.a3.isHidden = true
        }
        if(viewIntersectsView(person, second_View: a4))
        {
            self.a4.isHidden = true
        }
        if(viewIntersectsView(person, second_View: a5))
        {
            self.a5.isHidden = true
        }
    }
    
    func viewIntersectsView(_ first_View: UIView, second_View:UIView) -> Bool
    {
        return first_View.frame.intersects(second_View.frame)
    }
    
}
